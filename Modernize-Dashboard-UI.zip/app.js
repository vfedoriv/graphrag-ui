const WORKSPACES = {
  'claims-research': {
    name: 'Claims research',
    id: 'kb-claims-2026',
    schema: 'claim_event v3',
    schemas: '3 schemas',
    documents: '18 documents',
    note: 'Insurance claims workspace',
    query: 'Which claims mention water damage and policy exclusions?'
  },
  'clinical-notes': {
    name: 'Clinical notes',
    id: 'kb-clinical',
    schema: 'None active',
    schemas: '1 schema',
    documents: '7 documents',
    note: 'Medical note extraction workspace',
    query: 'Which notes mention medication changes after discharge?'
  },
  'vendor-contracts': {
    name: 'Vendor contracts',
    id: 'kb-contracts',
    schema: 'contract_clause v1',
    schemas: '2 schemas',
    documents: '11 documents',
    note: 'Procurement contract workspace',
    query: 'Which contracts include renewal or termination clauses?'
  }
};

const WORKSPACE_KEY = 'graphrag-ui:selected-workspace';

function readStoredValue(key) {
  try {
    return localStorage.getItem(key);
  } catch (_) {
    return null;
  }
}

function writeStoredValue(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch (_) {}
}

function getWorkspace() {
  const saved = readStoredValue(WORKSPACE_KEY);
  return WORKSPACES[saved] ? saved : 'claims-research';
}

function paintWorkspace(key) {
  const workspace = WORKSPACES[key] || WORKSPACES['claims-research'];
  document.querySelectorAll('[data-workspace-select]').forEach((select) => {
    select.value = key;
  });
  document.querySelectorAll('[data-workspace-name]').forEach((node) => {
    if ('value' in node) node.value = workspace.name;
    else node.textContent = workspace.name;
  });
  document.querySelectorAll('[data-workspace-id]').forEach((node) => {
    if ('value' in node) node.value = workspace.id;
    else node.textContent = workspace.id;
  });
  document.querySelectorAll('[data-workspace-schema]').forEach((node) => {
    node.textContent = workspace.schema;
    node.classList.toggle('success', workspace.schema !== 'None active');
    node.classList.toggle('warning', workspace.schema === 'None active');
  });
  document.querySelectorAll('[data-workspace-schemas]').forEach((node) => {
    node.textContent = workspace.schemas;
  });
  document.querySelectorAll('[data-workspace-documents]').forEach((node) => {
    node.textContent = workspace.documents;
  });
  document.querySelectorAll('[data-workspace-note]').forEach((node) => {
    node.textContent = workspace.note;
  });
  document.querySelectorAll('[data-schema-readiness]').forEach((node) => {
    node.textContent = workspace.schema === 'None active'
      ? 'Schema-gated actions should route to the schema workbench before document processing.'
      : 'Extraction and validation use this active schema.';
  });
  document.querySelectorAll('[data-workspace-query]').forEach((node) => {
    if ('value' in node) node.value = workspace.query;
    else node.textContent = workspace.query;
  });
  document.querySelectorAll('[data-workspace-row]').forEach((row) => {
    const isSelected = row.dataset.workspaceRow === key;
    row.classList.toggle('is-selected', isSelected);
    const status = row.querySelector('[data-selected-workspace-status]');
    if (status) {
      status.textContent = isSelected ? 'Selected' : 'Available';
      status.classList.toggle('success', isSelected);
      status.classList.toggle('neutral', !isSelected);
    }
    const useButton = row.querySelector('[data-use-workspace]');
    if (useButton) {
      useButton.textContent = isSelected ? 'Current' : 'Use';
      useButton.toggleAttribute('disabled', isSelected);
      useButton.setAttribute('aria-label', isSelected
        ? `${workspace.name} is the current workspace`
        : `Use ${WORKSPACES[row.dataset.workspaceRow].name} workspace`);
    }
  });
}

document.querySelectorAll('[data-workspace-select]').forEach((select) => {
  select.addEventListener('change', () => {
    writeStoredValue(WORKSPACE_KEY, select.value);
    paintWorkspace(select.value);
  });
});

document.querySelectorAll('[data-use-workspace]').forEach((button) => {
  button.addEventListener('click', () => {
    const key = button.dataset.useWorkspace;
    if (!WORKSPACES[key]) return;
    writeStoredValue(WORKSPACE_KEY, key);
    paintWorkspace(key);
  });
});

paintWorkspace(getWorkspace());

document.querySelectorAll('[data-tabs]').forEach((root) => {
  const tabs = Array.from(root.querySelectorAll('[data-tab]'));
  const panels = Array.from(root.querySelectorAll('[data-tab-panel], .tab-panel'));
  const activateTab = (tab) => {
    const id = tab.dataset.tab;
    tabs.forEach((item) => {
      const isActive = item === tab;
      item.classList.toggle('active', isActive);
      item.setAttribute('aria-selected', String(isActive));
      item.setAttribute('tabindex', isActive ? '0' : '-1');
    });
    panels.forEach((panel) => {
      const panelId = panel.dataset.tabPanel || panel.id;
      const isActive = panelId === id;
      panel.classList.toggle('active', isActive);
      panel.hidden = !isActive;
    });
  };
  tabs.forEach((tab) => {
    tab.type = 'button';
    tab.setAttribute('aria-selected', String(tab.classList.contains('active')));
    tab.addEventListener('click', () => {
      activateTab(tab);
    });
  });
  activateTab(tabs.find((tab) => tab.classList.contains('active')) || tabs[0]);
});

document.querySelectorAll('[data-run]').forEach((button) => {
  button.addEventListener('click', () => {
    const target = document.querySelector(button.dataset.run);
    const original = button.textContent;
    button.disabled = true;
    button.textContent = button.dataset.pending || 'Running...';
    setTimeout(() => {
      button.disabled = false;
      button.textContent = original;
      if (target) target.textContent = button.dataset.result || 'Request completed. Output is ready for review.';
      if (button.dataset.stateTarget) {
        const stateTarget = document.querySelector(button.dataset.stateTarget);
        if (stateTarget) stateTarget.textContent = button.dataset.state || 'Request completed.';
      }
    }, 650);
  });
});

document.querySelectorAll('[data-settings-action]').forEach((button) => {
  button.addEventListener('click', () => {
    const target = document.querySelector(button.dataset.target);
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Applying...';
    setTimeout(() => {
      button.disabled = false;
      button.textContent = original;
      if (target) {
        const workspace = WORKSPACES[getWorkspace()] || WORKSPACES['claims-research'];
        target.textContent = `${button.dataset.message} Active scope: ${workspace.id} (${workspace.name}).`;
      }
    }, 520);
  });
});
